import {DeliveryClient} from "@kentico/kontent-delivery";

export const deliveryClient = new DeliveryClient({
  // Tip: Use your own sample project ID instead of the Sample Project ID
  projectId: "975bf280-fd91-488c-994c-2f04416e5ee3",
});